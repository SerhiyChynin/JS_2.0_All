const URL = "https://api.itgid.info";
const APIKEY = "впишите_сюда_ваш_api_key";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!