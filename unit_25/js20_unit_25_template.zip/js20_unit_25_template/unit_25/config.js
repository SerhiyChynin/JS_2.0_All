const URL = "https://api.itgid.info";
const APIKEY = "ObEzqRmgSvy0Wcny";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!