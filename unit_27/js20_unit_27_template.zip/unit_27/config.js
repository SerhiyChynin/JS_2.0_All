const URL = "https://api.itgid.info";
const APIKEY = "сюда_напишите_ваш_api_key";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!