const URL = "https://api.itgid.info";
const APIKEY = "MHV4Z8mkb0KjJGwY";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!