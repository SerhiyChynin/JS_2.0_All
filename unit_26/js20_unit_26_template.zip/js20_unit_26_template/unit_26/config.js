const URL = "https://api.itgid.info";
const APIKEY = "GIcZVhF9U6Sz8fFE";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!